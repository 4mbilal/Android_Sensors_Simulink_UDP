package com.example.Android_Sensors_UDP;


interface OnFragmentInteractionListener {
   void onFragmentCreate (String name);
   void onFragmentStart  (String name);
   void onFragmentPause  (String name);
   void onFragmentResume (String name);
}
